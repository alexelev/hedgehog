<?php
/**
 * @package seopro
 */
class seoKeywords extends xPDOSimpleObject {}
?>