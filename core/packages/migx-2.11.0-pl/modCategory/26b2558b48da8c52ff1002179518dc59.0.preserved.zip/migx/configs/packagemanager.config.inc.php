<?php

$this->customconfigs['cmptabcaption'] = "Package Manager";
$this->customconfigs['cmptabdescription'] = "Here you can Manage your Packages.";
$this->customconfigs['cmptabcontroller'] = "packagemanager";