<?php
/**
 * migx
 *
 * @package migx
 * @language ru
 */


$_lang['mig.tabs'] = 'Вкладки формы';
$_lang['mig.columns'] = 'Разметка колонок';
$_lang['mig.btntext'] = 'Замена кнопки "Добавить элемент"';
$_lang['mig.previewurl'] = 'Просмотр Url';
$_lang['mig.jsonvarkey'] = 'Просмотр JsonVarKey';
$_lang['mig.configs'] = 'Конфигурации';
$_lang['mig.autoResourceFolders'] = 'Auto Resource Folders';