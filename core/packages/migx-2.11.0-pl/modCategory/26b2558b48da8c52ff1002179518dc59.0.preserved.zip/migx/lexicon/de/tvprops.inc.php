<?php
/**
 * migx
 *
 * @package migx
 * @language de
 */


$_lang['mig.tabs'] = 'Formular-Tabs';
$_lang['mig.columns'] = 'Tabellenspalten';
$_lang['mig.btntext'] = 'Andere Beschriftung für den Button "Datensatz erstellen"';
$_lang['mig.previewurl'] = 'Vorschau-URL';
$_lang['mig.jsonvarkey'] = 'JsonVarKey für die Vorschau';
$_lang['mig.configs'] = 'Konfigurationen';
$_lang['mig.autoResourceFolders'] = 'Auto-Ressourcen-Ordner';